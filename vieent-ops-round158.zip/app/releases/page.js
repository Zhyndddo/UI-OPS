"use client";

import AppShell from "../../lib/AppShell";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { supabase } from "../../lib/supabaseClient";
import { fmtDate, metadataPercent, uploadPercent, fetchAllRows } from "../../lib/helpers";
import { buildProductNote } from "../../lib/releaseNotes";
import { useSortableRows } from "../../lib/useSortableRows";
import SortableTh, { ResetSortButton } from "../../lib/SortableTh";
import { usePagination } from "../../lib/usePagination";
import Pagination from "../../lib/Pagination";
import { fetchProductTagSets, ProductTagPills } from "../../lib/productTags";
import { copyrightChecklistSummary } from "../../lib/copyrightChecklist";
import DateRangeFilter, { matchesDateRange } from "../../lib/DateRangeFilter";
import styles from "../shared.module.css";

const CHANNELS = ["VIEENT", "ENVI"];

// Round 86 follow-up item 1 (load speed) — releases is a genuinely wide
// table (every workstation's own checklist/gate/confirm columns live on
// it too — see schema.sql), but this dashboard only ever reads the fields
// below (directly, or through metadataPercent()/uploadPercent()/
// pitchingSummary() in lib/helpers.js and this file). `select("*")` was
// pulling every column across the wire for every row on every load — this
// cuts that payload down to what's actually rendered. Keep this list in
// sync if the dashboard starts reading a new release field.
const RELEASE_COLUMNS = [
  "id", "did", "title", "main_artist", "label", "media_report_status", "project_type",
  "pseudo_package_parent_did", "release_category", "release_date", "release_time",
  "requester_segment", "status", "created_at",
  // metadataPercent()
  "meta_audio", "meta_artwork", "meta_working_files", "meta_lyric", "meta_mv", "meta_doc",
  // uploadPercent()
  "link_lbm", "link_share", "smartlink", "gate_pre_order", "link_preorder",
  // pitchingSummary()/pitchingStatusFor()
  "priority_pitching", "pitching_status_spotify", "pitching_status_apple", "pitching_status_nct", "pitching_status_zing",
  // Round 88 — Copyright Checklist compiled summary subrow
  "copyright_checklist",
].join(", ");

// Mirrors app/workstation/pitching/page.js's DONE_VALUE/CANCEL_VALUES so the
// dashboard's "Status Pitching" column agrees with the Pitching workstation
// about what "done"/"cancelled" mean, instead of drifting into its own
// definition.
const PITCHING_DONE_VALUE = "Đã pitching";
const PITCHING_CANCEL_VALUES = ["Không thực hiện", "Không hỗ trợ"];
const PITCHING_TYPE_KEYS = ["priority", "spotify", "apple", "nct", "zing"]; // round 79 — Apple joined as a real tracked platform

function pitchingStatusFor(release, key) {
  if (key === "priority") return release?.priority_pitching;
  if (key === "spotify") return release?.pitching_status_spotify;
  if (key === "apple") return release?.pitching_status_apple;
  if (key === "nct") return release?.pitching_status_nct;
  if (key === "zing") return release?.pitching_status_zing;
  return null;
}

// "Status Pitching" summary for a release, given the selected types from its
// Pitching ticket (ticket.data — see app/releases/[id]/page.js's
// pitchingTypesDraft) and the per-type status columns on the release itself.
function pitchingSummary(release, ticketData) {
  if (!ticketData) return { label: "Not requested", tone: "gray" };
  const types = PITCHING_TYPE_KEYS.filter((k) => ticketData[k]);
  if (types.length === 0) return { label: "Not requested", tone: "gray" };
  if (types.every((k) => pitchingStatusFor(release, k) === PITCHING_DONE_VALUE)) return { label: "Done", tone: "orange" };
  if (types.every((k) => PITCHING_CANCEL_VALUES.includes(pitchingStatusFor(release, k)))) return { label: "Cancelled", tone: "gray" };
  return { label: "In Progress", tone: "yellow" };
}

export default function ReleasesDashboard() {
  const [releases, setReleases] = useState([]);
  const [bookingPct, setBookingPct] = useState({}); // release_id -> %
  const [pitchingData, setPitchingData] = useState({}); // did -> pitching ticket's data (selected types)
  const [labels, setLabels] = useState([]);
  const [productTagSets, setProductTagSets] = useState({}); // Round 86 item 5 — see lib/productTags.js
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [savingChannel, setSavingChannel] = useState(null); // release id currently being saved

  const [statusFilter, setStatusFilter] = useState(null); // "preRelease" | "released" | "postRelease"
  const [createdFilter, setCreatedFilter] = useState(null); // "today" | "week" | "month"
  const [channelFilter, setChannelFilter] = useState(null); // "VIEENT" | "ENVI" (from stat click or dropdown, same state)
  const [typeFilter, setTypeFilter] = useState("");
  const [labelFilter, setLabelFilter] = useState("");
  const [search, setSearch] = useState(""); // regex tested against main_artist, title, label
  // Round 152 — new, independent custom date-range filter, sits next to
  // the search box. ANDed with everything else (including the existing
  // today/this-week/this-month preset filter above — this doesn't replace
  // or repurpose that, both can be active together) via matchesDateRange
  // below. See lib/DateRangeFilter.js for why it's built as a generic,
  // reusable component rather than page-specific.
  const [dateRangeStart, setDateRangeStart] = useState("");
  const [dateRangeEnd, setDateRangeEnd] = useState("");
  const [hoverRelease, setHoverRelease] = useState(null);
  const [hoverPos, setHoverPos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (!supabase) return;
    (async () => {
      // Round 86 follow-up item 1 (load speed) — these 5 fetches don't
      // depend on each other (each reads its own table/tab), but used to
      // run one after another, so the page's total wait was roughly the
      // SUM of all of them instead of just the slowest one. Running them
      // together cuts that down to one round trip's worth of wall-clock
      // time. Only the pitching TICKETS fetch below genuinely depends on
      // pitchTabResult (needs its tab id first), so that one stays
      // sequential, after this batch resolves.
      const [releasesResult, bookingsResult, labelsResult, pitchTabResult, tagSets] = await Promise.all([
        // Round 60 — the Dashboard is the one place a truncated release
        // list would be most visible (rows just silently missing), so
        // this reads through fetchAllRows instead of a plain select() —
        // see DATA_FIXES.md round 59/60 for the 1000-row default cap this
        // works around. Sort needs a unique tiebreaker (id) for .range()
        // pagination to be stable across requests — created_at alone can
        // collide (e.g. a bulk import where many rows share the same
        // timestamp). select(RELEASE_COLUMNS) instead of select("*") —
        // see that const's comment just above this component.
        fetchAllRows(() =>
          supabase.from("releases").select(RELEASE_COLUMNS).order("created_at", { ascending: false }).order("id", { ascending: true })
        ),
        fetchAllRows(() => supabase.from("media_booking_entries").select("release_id, status").order("id")),
        supabase.from("labels").select("label_name").order("label_name"),
        // Pitching tickets — one per release (matched by DID, stored oddly
        // as data->>releaseId, same pattern as app/releases/[id]/page.js).
        // Used to compute the "Status Pitching" column below without
        // opening each release individually. Only the tab lookup itself
        // can join this batch — the tickets fetch that depends on its id
        // happens below, after this Promise.all resolves.
        supabase.from("ticket_tabs").select("id").eq("key", "pitching").single(),
        // Round 86 item 5 — one batched fetch (3 queries total, not one
        // per row) for the product tag pills' Publishing/Splitshare/Phụ
        // Lục MG ticket existence — see lib/productTags.js.
        fetchProductTagSets(supabase),
      ]);

      const { data, error: err } = releasesResult;
      if (err) { setError(err.message); setLoading(false); return; }
      setReleases(data || []);

      const { data: bookings } = bookingsResult;
      const grouped = {};
      (bookings || []).forEach((b) => {
        if (!grouped[b.release_id]) grouped[b.release_id] = { total: 0, done: 0 };
        grouped[b.release_id].total++;
        if (b.status === "Done") grouped[b.release_id].done++;
      });
      const pctMap = {};
      Object.entries(grouped).forEach(([id, g]) => (pctMap[id] = Math.round((g.done / g.total) * 100)));
      setBookingPct(pctMap);

      const { data: labelRows } = labelsResult;
      setLabels(labelRows || []);

      setProductTagSets(tagSets);

      const { data: pitchTab } = pitchTabResult;
      if (pitchTab) {
        const { data: pitchTix } = await supabase
          .from("tickets")
          .select("data")
          .eq("tab_id", pitchTab.id)
          .is("deleted_at", null);
        const map = {};
        (pitchTix || []).forEach((t) => {
          const did = t.data?.releaseId;
          if (did) map[did] = t.data;
        });
        setPitchingData(map);
      }

      setLoading(false);
    })();
  }, []);

  const stats = useMemo(() => {
    const now = new Date();
    const startOfToday = new Date(now);
    startOfToday.setHours(0, 0, 0, 0);
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - now.getDay());
    startOfWeek.setHours(0, 0, 0, 0);
    const startOfNextWeek = new Date(startOfWeek);
    startOfNextWeek.setDate(startOfWeek.getDate() + 7);
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfNextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);

    let today = 0, thisWeek = 0, thisMonth = 0, preRelease = 0, released = 0, postRelease = 0;
    const byChannel = { VIEENT: 0, ENVI: 0 };

    const startOfTomorrow = new Date(startOfToday);
    startOfTomorrow.setDate(startOfToday.getDate() + 1);

    releases.forEach((r) => {
      // "Today" means releasing today — same reasoning as This Week/This
      // Month below: release_date is what the team tracks against, not
      // created_at (when the row happened to be entered into the app).
      if (r.release_date) {
        const rdt = new Date(r.release_date);
        if (rdt >= startOfToday && rdt < startOfTomorrow) today++;
      }
      // "This Week" means releasing this week (Sunday through the following
      // Sunday), not created this week — same reasoning/fix as "This Month"
      // below: release_date is what the team actually cares about tracking
      // here, and it can be set well after (or, for backfilled data, well
      // before) created_at.
      if (r.release_date) {
        const rdw = new Date(r.release_date);
        if (rdw >= startOfWeek && rdw < startOfNextWeek) thisWeek++;
      }
      // "This Month" means releasing this month, not created this month —
      // reads release_date, with an upper bound too (release_date can be
      // months/years in the future, unlike created_at).
      if (r.release_date) {
        const rd0 = new Date(r.release_date);
        if (rd0 >= startOfMonth && rd0 < startOfNextMonth) thisMonth++;
      }

      const rd = r.release_date ? new Date(r.release_date) : null;
      if (rd) {
        if (rd > now) preRelease++;
        else {
          const daysSince = (now - rd) / (1000 * 60 * 60 * 24);
          if (daysSince <= 7) released++;
          else postRelease++;
        }
      }
      if (byChannel[r.requester_segment] !== undefined) byChannel[r.requester_segment]++;
    });

    return { total: releases.length, today, thisWeek, thisMonth, preRelease, released, postRelease, byChannel };
  }, [releases]);

  // Regex-first: if the typed text is a valid regex, it's tested as one
  // (case-insensitive) against artist/song/label; anything that fails to
  // compile (unbalanced groups, etc. — easy to type by accident) just
  // falls back to a plain case-insensitive substring match instead of
  // erroring the whole page out.
  const searchTest = useMemo(() => {
    const q = search.trim();
    if (!q) return null;
    try {
      const re = new RegExp(q, "i");
      return (s) => re.test(s || "");
    } catch {
      const needle = q.toLowerCase();
      return (s) => (s || "").toLowerCase().includes(needle);
    }
  }, [search]);

  // Round 86 item 2 — "Album Name" column resolves each row's
  // pseudo_package_parent_did against its parent release's title. The
  // dashboard already loads the entire releases table into memory (see
  // fetchAllRows above), so this is a free client-side lookup — no extra
  // query needed.
  const albumNameByDid = useMemo(() => {
    const map = new Map();
    releases.forEach((r) => { if (r.did) map.set(r.did, r.title); });
    return map;
  }, [releases]);

  const filteredReleases = useMemo(() => {
    const now = new Date();
    const startOfToday = new Date(now);
    startOfToday.setHours(0, 0, 0, 0);
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - now.getDay());
    startOfWeek.setHours(0, 0, 0, 0);
    const startOfNextWeek = new Date(startOfWeek);
    startOfNextWeek.setDate(startOfWeek.getDate() + 7);
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfNextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);

    const startOfTomorrow = new Date(startOfToday);
    startOfTomorrow.setDate(startOfToday.getDate() + 1);

    return releases.filter((r) => {
      if (createdFilter) {
        if (createdFilter === "today") {
          // Filters by release_date, not created_at — same fix as the stat
          // card above.
          if (!r.release_date) return false;
          const rdt = new Date(r.release_date);
          if (!(rdt >= startOfToday && rdt < startOfTomorrow)) return false;
        }
        if (createdFilter === "week") {
          // Same fix as the stat card above — "This Week" filters by
          // release_date (releasing Sunday through the following Sunday),
          // not created_at.
          if (!r.release_date) return false;
          const rdw = new Date(r.release_date);
          if (!(rdw >= startOfWeek && rdw < startOfNextWeek)) return false;
        }
        if (createdFilter === "month") {
          // Same fix as the stat card above — "This Month" filters by
          // release_date (releasing this month), not created_at.
          if (!r.release_date) return false;
          const rd0 = new Date(r.release_date);
          if (!(rd0 >= startOfMonth && rd0 < startOfNextMonth)) return false;
        }
      }
      if (statusFilter) {
        const rd = r.release_date ? new Date(r.release_date) : null;
        if (!rd) return false;
        if (statusFilter === "preRelease" && !(rd > now)) return false;
        if (statusFilter === "released" && !(rd <= now && (now - rd) / (1000 * 60 * 60 * 24) <= 7)) return false;
        if (statusFilter === "postRelease" && !(rd <= now && (now - rd) / (1000 * 60 * 60 * 24) > 7)) return false;
      }
      if (channelFilter && r.requester_segment !== channelFilter) return false;
      if (typeFilter && r.project_type !== typeFilter) return false;
      if (labelFilter && r.label !== labelFilter) return false;
      if (searchTest && !(searchTest(r.main_artist) || searchTest(r.title) || searchTest(r.label))) return false;
      // Round 152 — new custom date-range filter, independent of
      // createdFilter's presets above (both can be active at once).
      if (!matchesDateRange(r.release_date, dateRangeStart, dateRangeEnd)) return false;
      return true;
    });
  }, [releases, createdFilter, statusFilter, channelFilter, typeFilter, labelFilter, searchTest, dateRangeStart, dateRangeEnd]);

  // "nhớ cập nhật cái channel nhan" — the Channel column was read-only and
  // commonly blank (requester_segment is an optional dropdown on the create
  // form, nothing defaults or requires it), so fixing a batch of blanks
  // meant opening every release individually. Inline-editable here instead.
  async function updateChannel(release, value) {
    setSavingChannel(release.id);
    const { error: err } = await supabase.from("releases").update({ requester_segment: value || null }).eq("id", release.id);
    if (!err) {
      setReleases((rows) => rows.map((r) => (r.id === release.id ? { ...r, requester_segment: value || null } : r)));
    }
    setSavingChannel(null);
  }

  // Round 79's updateTrackDid (inline-editable EP/Album DID straight from
  // this dashboard row) was removed in round 86 item 2 — the column it fed
  // is now hidden here entirely (see the "Album Name" column below); the
  // field itself is untouched and still editable from the release detail
  // page.

  const { sorted: sortedReleases, sort, toggleSort, resetSort, isDefault } = useSortableRows(filteredReleases);
  const { pageRows: pagedReleases, page, setPage, pageSize, setPageSize, totalPages, totalRows } = usePagination(sortedReleases);

  const anyStatClickFilter = statusFilter || channelFilter || createdFilter;

  return (
    <AppShell>
    <div className={styles.page}>
      <div className={styles.container} style={{ maxWidth: 1400 }}>
        <div className={styles.topRow}>
          <div>
            <div className={styles.eyebrow}>// Overview</div>
            <h1 className={styles.title} style={{ marginBottom: 0 }}>New Release</h1>
          </div>
          <Link href="/new-release" className={styles.btnPrimary}>+ New Release</Link>
        </div>

        <div className={styles.statRow}>
          <StatCard label="Total Releases" value={stats.total} active={!createdFilter} onClick={() => setCreatedFilter(null)} onClear={() => setCreatedFilter(null)} hideClear />
          <StatCard label="Today" value={stats.today} active={createdFilter === "today"} onClick={() => setCreatedFilter((f) => (f === "today" ? null : "today"))} onClear={() => setCreatedFilter(null)} />
          <StatCard label="This Week" value={stats.thisWeek} active={createdFilter === "week"} onClick={() => setCreatedFilter((f) => (f === "week" ? null : "week"))} onClear={() => setCreatedFilter(null)} />
          <StatCard label="This Month" value={stats.thisMonth} active={createdFilter === "month"} onClick={() => setCreatedFilter((f) => (f === "month" ? null : "month"))} onClear={() => setCreatedFilter(null)} />
          <StatCard label="Pre-release" value={stats.preRelease} active={statusFilter === "preRelease"} onClick={() => setStatusFilter((f) => (f === "preRelease" ? null : "preRelease"))} onClear={() => setStatusFilter(null)} />
          <StatCard label="Release" value={stats.released} active={statusFilter === "released"} onClick={() => setStatusFilter((f) => (f === "released" ? null : "released"))} onClear={() => setStatusFilter(null)} />
          <StatCard label="Post-release" value={stats.postRelease} active={statusFilter === "postRelease"} onClick={() => setStatusFilter((f) => (f === "postRelease" ? null : "postRelease"))} onClear={() => setStatusFilter(null)} />
        </div>

        <div className={styles.subheading} style={{ marginTop: 4 }}>By Media Channel</div>
        <div className={styles.statRow} style={{ gridTemplateColumns: "repeat(3, 1fr)", marginBottom: 24 }}>
          <StatCard label="All" value={stats.total} active={!channelFilter} onClick={() => setChannelFilter(null)} onClear={() => setChannelFilter(null)} hideClear />
          {CHANNELS.map((c) => (
            <StatCard key={c} label={c} value={stats.byChannel[c] || 0} active={channelFilter === c} onClick={() => setChannelFilter((f) => (f === c ? null : c))} onClear={() => setChannelFilter(null)} />
          ))}
        </div>

        <div style={{ display: "flex", gap: 10, marginBottom: 20, flexWrap: "wrap", alignItems: "center" }}>
          <input
            className={styles.input}
            style={{ width: 260 }}
            placeholder="Tìm nghệ sĩ, bài hát, label… (hỗ trợ regex)"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <DateRangeFilter start={dateRangeStart} end={dateRangeEnd} onStartChange={setDateRangeStart} onEndChange={setDateRangeEnd} />
          <select className={styles.select} style={{ maxWidth: 200 }} value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)}>
            <option value="">Type — all</option>
            {[...new Set(releases.map((r) => r.project_type).filter(Boolean))].map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
          <select className={styles.select} style={{ maxWidth: 200 }} value={channelFilter || ""} onChange={(e) => setChannelFilter(e.target.value || null)}>
            <option value="">Channel — all</option>
            {CHANNELS.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
          <select className={styles.select} style={{ maxWidth: 200 }} value={labelFilter} onChange={(e) => setLabelFilter(e.target.value)}>
            <option value="">Label — all</option>
            {labels.map((l) => <option key={l.label_name} value={l.label_name}>{l.label_name}</option>)}
          </select>
          {(typeFilter || labelFilter || search || dateRangeStart || dateRangeEnd || anyStatClickFilter) && (
            <button
              onClick={() => { setStatusFilter(null); setChannelFilter(null); setCreatedFilter(null); setTypeFilter(""); setLabelFilter(""); setSearch(""); setDateRangeStart(""); setDateRangeEnd(""); }}
              style={{ background: "none", border: "1px solid var(--border-strong)", borderRadius: 6, padding: "6px 12px", fontSize: 11, color: "var(--text-faint)", cursor: "pointer" }}
            >
              ✕ Clear all filters
            </button>
          )}
          <ResetSortButton isDefault={isDefault} onReset={resetSort} styles={styles} />
        </div>

        {error && <div className={styles.errorBox}>{error}</div>}

        {loading ? (
          <div className={styles.emptyState}>Loading…</div>
        ) : sortedReleases.length === 0 ? (
          <div className={styles.emptyState}>No releases match these filters.</div>
        ) : (
          <>
          <div className={styles.scrollBox} style={{ overflowX: "auto" }}>
          <table className={styles.table}>
            <thead>
              <tr>
                <SortableTh label="DID" sortKey="did" sort={sort} onToggle={toggleSort} />
                <SortableTh label="Channel" sortKey="requester_segment" sort={sort} onToggle={toggleSort} />
                <SortableTh label="Package" sortKey="release_category" sort={sort} onToggle={toggleSort} />
                <SortableTh label="Label" sortKey="label" sort={sort} onToggle={toggleSort} />
                {/* Round 86 follow-up items 1 & 2 — widened to ~1.5x its old
                    natural (unset) width (item 2), now that both the
                    product tag pills (item 5) and the Album Name subtitle
                    (item 1 — see below) live in this column and need room.
                    Album Name started as its own column (round 86 item 2)
                    but per follow-up item 1 is now a subtitle line under
                    the title instead, freeing up a column. */}
                <SortableTh label="Name" sortKey="title" sort={sort} onToggle={toggleSort} style={{ minWidth: 260 }} />
                <SortableTh label="Artist" sortKey="main_artist" sort={sort} onToggle={toggleSort} />
                {/* Round 86 follow-up item 5 — merged Release Date +
                    Release Time into one column per explicit request
                    ("Merge into one 'Release' column"). Still sorts by
                    release_date — release_time is just appended for
                    display, not a separate sortable dimension anymore. */}
                <SortableTh label="Release" sortKey="release_date" sort={sort} onToggle={toggleSort} />
                <SortableTh label="Status" sortKey="status" sort={sort} onToggle={toggleSort} />
                <th>Status Pitching</th>
                <th>Metadata</th>
                <th>Booking</th>
                <th>Upload</th>
              </tr>
            </thead>
            <tbody>
              {pagedReleases.map((r) => {
                const pct = metadataPercent(r);
                const bpct = bookingPct[r.id] ?? 0;
                const upct = uploadPercent(r);
                const pitching = pitchingSummary(r, pitchingData[r.did]);
                return (
                  <tr key={r.id}>
                    <td
                      onMouseEnter={(e) => { setHoverRelease(r); setHoverPos({ x: e.clientX, y: e.clientY }); }}
                      onMouseLeave={() => setHoverRelease(null)}
                    >
                      <Link href={`/releases/${r.id}`} className={styles.rowLink}>{r.did || "—"}</Link>
                    </td>
                    <td onClick={(e) => e.stopPropagation()}>
                      <select
                        className={styles.select}
                        style={{ minWidth: 100, opacity: savingChannel === r.id ? 0.5 : 1 }}
                        value={r.requester_segment || ""}
                        disabled={savingChannel === r.id}
                        onChange={(e) => updateChannel(r, e.target.value)}
                        title={
                          r.requester_segment && !CHANNELS.includes(r.requester_segment)
                            ? `Imported value doesn't match VIEENT/ENVI exactly — pick one to fix it`
                            : undefined
                        }
                      >
                        <option value="">—</option>
                        {CHANNELS.map((c) => <option key={c} value={c}>{c}</option>)}
                        {/* An imported/legacy value that isn't exactly "VIEENT" or "ENVI"
                            (different casing, a typo, a different word entirely from the
                            source sheet) used to just render blank here — the data was
                            really in requester_segment, this <select> just had no <option>
                            for it. Surfacing it as its own option instead of silently
                            dropping it — see scripts/audit-release-channel.js to find every
                            release affected this way. */}
                        {r.requester_segment && !CHANNELS.includes(r.requester_segment) && (
                          <option value={r.requester_segment}>{r.requester_segment} (unrecognized — pick to fix)</option>
                        )}
                      </select>
                    </td>
                    <td style={{ maxWidth: 260, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                      {r.release_category ? `${r.release_category} - ${r.project_type || "—"}` : (r.project_type || "—")}
                    </td>
                    <td>{r.label || "—"}</td>
                    <td
                      onMouseEnter={(e) => { setHoverRelease(r); setHoverPos({ x: e.clientX, y: e.clientY }); }}
                      onMouseLeave={() => setHoverRelease(null)}
                    >
                      <Link href={`/releases/${r.id}`} className={styles.rowLink}>{r.title}</Link>
                      {/* Round 86 follow-up item 1 — Album Name as a
                          subtitle line here instead of its own column
                          (was a separate "Album Name" column in the first
                          round-86 pass). */}
                      {r.pseudo_package_parent_did && albumNameByDid.get(r.pseudo_package_parent_did) && (
                        <div style={{ fontSize: 11, color: "var(--text-faint)", marginTop: 2 }}>
                          {albumNameByDid.get(r.pseudo_package_parent_did)}
                        </div>
                      )}
                      {/* Round 86 item 5 — product tag pills */}
                      <ProductTagPills styles={styles} release={r} tagSets={productTagSets} style={{ marginTop: 4 }} />
                      {/* Round 88 item 1d — Copyright Checklist compiled
                          into one small subrow line ("Q1: Tự SX · Q2:
                          HTĐQ · …"), layer-1 choice only per explicit
                          spec. Hidden entirely once nothing's been filled
                          in yet. */}
                      {copyrightChecklistSummary(r.copyright_checklist) && (
                        <div style={{ fontSize: 10, color: "var(--text-faint)", marginTop: 4 }}>
                          {copyrightChecklistSummary(r.copyright_checklist)}
                        </div>
                      )}
                    </td>
                    <td>{r.main_artist}</td>
                    <td>{fmtDate(r.release_date)}{r.release_time ? ` ${r.release_time}` : ""}</td>
                    <td>
                      <span className={styles.statusBadge} style={{ background: "rgba(255,107,26,0.12)", color: "#ff9d5c" }}>{r.status}</span>
                      {/* Round 54 — item B.1: surfaces the Booking Board's
                          "Convert Media Report" state here on the New
                          Release Dashboard too, per "add tab booking status
                          (NEW RELEASE DASHBOARD): Đã có media report" — the
                          board itself is where Convert/Send Artist actually
                          happen (fixed "Media Report" column), this is just
                          the read-only marker showing up here as well. */}
                      {r.media_report_status && (
                        <span
                          className={styles.statusBadge}
                          style={{ display: "block", marginTop: 4, background: r.media_report_status === "sent" ? "rgba(126,230,168,0.14)" : "rgba(255,202,77,0.14)", color: r.media_report_status === "sent" ? "#7ee6a8" : "#ffca4d" }}
                        >
                          {r.media_report_status === "sent" ? "Media Report — Artist Sent" : "Đã có media report"}
                        </span>
                      )}
                    </td>
                    <td>
                      <span
                        className={styles.statusBadge}
                        style={
                          pitching.tone === "orange"
                            ? { background: "rgba(255,107,26,0.12)", color: "#ff9d5c" }
                            : pitching.tone === "yellow"
                            ? { background: "rgba(234,179,8,0.14)", color: "#eab308" }
                            : { background: "rgba(148,163,184,0.14)", color: "var(--text-faint)" }
                        }
                      >
                        {pitching.label}
                      </span>
                    </td>
                    <td>
                      <span className={`${styles.pill} ${pct > 0 ? styles.pillOrange : styles.pillGray}`}>{pct}%</span>
                    </td>
                    <td>
                      <span className={`${styles.pill} ${bpct > 0 ? styles.pillOrange : styles.pillGray}`}>{bpct}%</span>
                    </td>
                    <td>
                      <span className={`${styles.pill} ${upct > 0 ? styles.pillOrange : styles.pillGray}`}>{upct}%</span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          </div>
          <Pagination page={page} setPage={setPage} pageSize={pageSize} setPageSize={setPageSize} totalPages={totalPages} totalRows={totalRows} styles={styles} />
          </>
        )}
      </div>
    </div>

    {hoverRelease && (
      <div
        style={{
          position: "fixed",
          left: Math.min(hoverPos.x + 16, (typeof window !== "undefined" ? window.innerWidth : 1200) - 380),
          top: hoverPos.y + 16,
          zIndex: 500,
          width: 360,
          maxHeight: 420,
          overflow: "hidden",
          background: "var(--bg-card)",
          border: "1px solid var(--border-strong)",
          borderRadius: 8,
          padding: 14,
          pointerEvents: "none",
          boxShadow: "0 8px 24px rgba(0,0,0,0.4)",
        }}
      >
        <div style={{ fontSize: 10, color: "var(--accent)", fontWeight: 700, marginBottom: 4 }}>{hoverRelease.did}</div>
        <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 6 }}>{hoverRelease.title}</div>
        <div style={{ fontSize: 12, color: "var(--text-muted)", marginBottom: 8 }}>{hoverRelease.main_artist} · {hoverRelease.label}</div>
        {/* Round 78 — per explicit request, this now shows the same
            generated product note as the New Release Setup workstation's
            Note popup (lib/releaseNotes.js's buildProductNote — title,
            artist, release date/time, channel, then LINK DRIVE/LINK
            SHARE/SMARTLINK/LINKDASH/UPC/LINK UGC/MEDIA REPORT, whichever
            are filled in) instead of the previous Genre/Topic/Stage/
            Metadata/Booking/Upload summary. */}
        <pre style={{ fontSize: 11, color: "var(--text-faint)", whiteSpace: "pre-wrap", margin: 0, fontFamily: "inherit" }}>
{buildProductNote(hoverRelease)}
        </pre>
      </div>
    )}
    </AppShell>
  );
}

function StatCard({ label, value, active, onClick, onClear, hideClear }) {
  return (
    <div
      onClick={onClick}
      style={{
        position: "relative",
        cursor: "pointer",
        background: active ? "rgba(255,107,26,0.08)" : undefined,
        border: active ? "1px solid var(--accent)" : undefined,
        borderRadius: active ? 8 : undefined,
      }}
      className={active ? undefined : styles.statCard}
    >
      {active && !hideClear && (
        <button
          onClick={(e) => { e.stopPropagation(); onClear(); }}
          style={{ position: "absolute", top: 6, right: 6, background: "none", border: "none", color: "var(--text-faint)", cursor: "pointer", fontSize: 12, padding: 0 }}
        >
          ✕
        </button>
      )}
      <div className={styles.statLabel} style={active ? { padding: "16px 16px 0" } : undefined}>{label}</div>
      <div className={styles.statValue} style={active ? { padding: "0 16px 16px" } : undefined}>{value}</div>
    </div>
  );
}
